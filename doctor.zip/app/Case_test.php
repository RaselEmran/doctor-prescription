<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Case_test extends Model
{
    //
}
