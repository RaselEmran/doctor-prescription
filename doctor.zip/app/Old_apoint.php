<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Old_apoint extends Model
{
    //
}
