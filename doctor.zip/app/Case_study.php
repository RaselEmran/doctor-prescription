<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Case_study extends Model
{
    //
}
