<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Case_medi extends Model
{
    //
}
